<?php
/*
 
 * shortcode created to display a location 
 */

 
 
 class wp_location_shortcode{
 	

	public function __construct(){
		add_action('init', array($this,'register_location_shortcodes')); //shortcodes
	}

	
	public function register_location_shortcodes(){
		add_shortcode('wp_locations', array($this,'location_shortcode_output'));
	}
	

	public function location_shortcode_output($atts, $content = '', $tag){
			
		
		global $wp_simple_locations;
			
		
		$arguments = shortcode_atts(array(
			'location_id' => '',
			'number_of_locations' => -1)
		,$atts,$tag);
		
		
		$html = $wp_simple_locations->get_locations_output($arguments);
		
		return $html;
	}

 }
 $wp_location_shortcode = new wp_location_shortcode;

 
 

?>