
<?php




class wp_location_widget extends WP_widget{
	

	public function __construct(){
		
		parent::__construct(
			'wp_location_widget',
			'WP Location Widget', 
			array('description' => 'A widget that displays your locations')
		);
		add_action('widgets_init',array($this,'register_wp_location_widgets'));
	}
	

	public function widget( $args, $instance ) {
		
	
		global $wp_simple_locations;
		
	
		$arguments = array();
		
		
		
		if($instance['location_id'] != 'default'){
			$arguments['location_id'] = $instance['location_id'];
		}
		
		if($instance['number_of_locations'] != 'default'){
			$arguments['number_of_locations'] = $instance['number_of_locations'];
		}
		
		
		$html = '';
		
		$html .= $args['before_widget'];
		$html .= $args['before_title'];
		$html .= 'Locations';
		$html .= $args['after_title'];
		
		$html .= $wp_simple_locations->get_locations_output($arguments);
		$html .= $args['after_widget'];
		
		echo $html;
	}
	
	
	public function form($instance){
		//collect variables 
		$location_id = (isset($instance['location_id']) ? $instance['location_id'] : 'default');
		$number_of_locations = (isset($instance['number_of_locations']) ? $instance['number_of_locations'] : 5);
		
		?>
		<p>Select your options below</p>
		<p>
			<label for="<?php echo $this->get_field_name('location_id'); ?>">Location</label>
			<select class="widefat" name="<?php echo $this->get_field_name('location_id'); ?>" id="<?php echo $this->get_field_id('location_id'); ?>" value="<?php echo $location_id; ?>">
				<option value="default">Locations details</option>
				
				
				<?php
				$args = array(
					'posts_per_page'	=> -1,
					'post_type'			=> 'wp_locations'
				);
				$locations = get_posts($args);
				if($locations){
					foreach($locations as $location){
						if($location->ID == $location_id){
							echo '<option selected value="' . $location->ID . '">' . get_the_title($location->ID) . '</option>';
						}else{
							echo '<option value="' . $location->ID . '">' . get_the_title($location->ID) . '</option>';
						}
					}
				}
				?>
			</select>
		</p>
		<p>
			<small>If you want to display multiple locations select how many below</small><br/>
			<label for=  "<?php echo $this->get_field_id('number_of_locations'); ?>">Number of Locations</label>
			<select class="widefat" name="<?php echo $this->get_field_name('number_of_locations'); ?>" id="<?php echo $this->get_field_id('number_of_locations'); ?>" value="<?php echo $number_of_locations; ?>">
				<option value="default">All</option>
			</select>
		</p>
		<?php
	}
	

	public function update($new_instance, $old_instance){

		$instance = array();
		
		$instance['location_id'] = $new_instance['location_id'];
		$instance['number_of_locations'] = $new_instance['number_of_locations'];
		
		return $instance;
	}
	

	public function register_wp_location_widgets(){
		register_widget('wp_location_widget');
	}
}


$wp_location_widget = new wp_location_widget;

?>