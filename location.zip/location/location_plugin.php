<?php
/*
Plugin Name: Location Plugin
Description: Useful for managing store / business locations on your website, showing location based information quickly. 
Version:     2.0
Author:      Rabin Acharya


*/

class wp_simple_location{
	

	private $wp_location_trading_hour_days = array();
	
	
	public function __construct(){
		
		register_activation_hook(__FILE__, array($this,'plugin_activate')); 
		add_action('init', array($this,'set_location_trading_hour_days')); 
		add_action('init', array($this,'register_location_content_type')); 
		add_action('add_meta_boxes', array($this,'add_location_meta_boxes')); 
		add_action('save_post_wp_locations', array($this,'save_location')); 
		add_action('admin_enqueue_scripts', array($this,'enqueue_admin_scripts_and_styles')); 
		add_action('wp_enqueue_scripts', array($this,'enqueue_public_scripts_and_styles')); 
		add_filter('the_content', array($this,'prepend_location_meta_to_content')); 
		register_deactivation_hook(__FILE__, array($this,'plugin_deactivate'));
		
		
		 
		
	}
	
	
	public function set_location_trading_hour_days(){
		
		
		$this->wp_location_trading_hour_days = apply_filters('wp_location_trading_hours_days', 
			array('monday' => 'Monday',
				  'tuesday' => 'Tuesday',
				  'wednesday' => 'Wednesday',
				  'thursday' => 'Thursday',
				  'friday' => 'Friday',
				  'saturday' => 'Saturday',
				  'sunday' => 'Sunday',
			)
		);		
	}
	
	
	public function register_location_content_type(){
		
		 $labels = array(
            'name'               => 'Location',
            'singular_name'      => 'Location',
            'menu_name'          => 'Locations',
            'name_admin_bar'     => 'Location',
            'add_new'            => 'Add New', 
            'add_new_item'       => 'Add New Location',
            'new_item'           => 'New Location', 
            'edit_item'          => 'Edit Location',
            'view_item'          => 'View Location',
            'all_items'          => 'All Locations',
            'search_items'       => 'Search Locations',
            'parent_item_colon'  => 'Parent Location:', 
            'not_found'          => 'No Locations found.', 
            'not_found_in_trash' => 'No Locations found in Trash.',
        );
        
        $args = array(
            'labels'            => $labels,
            'public'            => true,
            'publicly_queryable'=> true,
            'show_ui'           => true,
            'show_in_nav'       => true,
            'query_var'         => true,
            'hierarchical'      => false,
            'supports'          => array('title','thumbnail','editor'),
            'has_archive'       => true,
            'menu_position'     => 20,
            'show_in_admin_bar' => true,
            'menu_icon'         => 'dashicons-location-alt',
            'rewrite'			=> array('slug' => 'locations', 'with_front' => 'true')
        );
        
        register_post_type('wp_locations', $args);
	}


	public function add_location_meta_boxes(){
		
		add_meta_box(
			'wp_location_meta_box', 
			'Location Information', 
			array($this,'location_meta_box_display'), 
			'wp_locations',
			'normal', 
			'default' 
		);
	}
	
	
	public function location_meta_box_display($post){
		
		
		wp_nonce_field('wp_location_nonce', 'wp_location_nonce_field');
		
		
		$wp_location_phone = get_post_meta($post->ID,'wp_location_phone',true);
		$wp_location_email = get_post_meta($post->ID,'wp_location_email',true);
		$wp_location_address = get_post_meta($post->ID,'wp_location_address',true);
		
		?>
		<p>Enter additional information about your location </p>
		<div class="field-container">
			<?php 
			
			do_action('wp_location_admin_form_start'); 
			?>
			<div class="field">
				<label for="wp_location_phone">Contact Phone</label>
				<small>main contact number</small>
				<input type="tel" name="wp_location_phone" id="wp_location_phone" value="<?php echo $wp_location_phone;?>"/>
			</div>
			<div class="field">
				<label for="wp_location_email">Contact Email</label>
				<small>Email contact</small>
				<input type="email" name="wp_location_email" id="wp_location_email" value="<?php echo $wp_location_email;?>"/>
			</div>
			<div class="field">
				<label for="wp_location_address">Address</label>
				<small>Physical address of your location</small>
				<textarea name="wp_location_address" id="wp_location_address"><?php echo $wp_location_address;?></textarea>
			</div>
			<?php
			
			if(!empty($this->wp_location_trading_hour_days)){
				
				echo '<div class="field">';
					echo '<label>Trading Hours </label>';
					echo '<small> Trading hours for the location (e.g 9am - 5pm) </small>';
					
					
					foreach($this->wp_location_trading_hour_days as $day_key => $day_value){
						
						
						$wp_location_trading_hour_value =  get_post_meta($post->ID,'wp_location_trading_hours_' . $day_key, true);
						
						
						
						echo '<label for="wp_location_trading_hours_' . $day_key . '">' . $day_key . '</label>';
						echo '<input type="text" name="wp_location_trading_hours_' . $day_key . '" id="wp_location_trading_hours_' . $day_key . '" value="' . $wp_location_trading_hour_value . '"/>';
					}
				echo '</div>';
			}		
			?>
		<?php 
		
		
		do_action('wp_location_admin_form_end'); 
		?>
		</div>
		<?php
		
	}
	
	
	public function plugin_activate(){
		
		
	 	$this->register_location_content_type();
	
		flush_rewrite_rules();
	}
	
	
	public function plugin_deactivate(){
	
		flush_rewrite_rules();
	}
	
	
	public function prepend_location_meta_to_content($content){
			
		global $post, $post_type;
		
		
		if($post_type == 'wp_locations' && is_singular('wp_locations')){
			
			
			$wp_location_id = $post->ID;
			$wp_location_phone = get_post_meta($post->ID,'wp_location_phone',true);
			$wp_location_email = get_post_meta($post->ID,'wp_location_email',true);
			$wp_location_address = get_post_meta($post->ID,'wp_location_address',true);
			
			
			$html = '';
	
			$html .= '<section class="meta-data">';
			
			
			do_action('wp_location_meta_data_output_start',$wp_location_id);
			
			$html .= '<p>';
		
			if(!empty($wp_location_phone)){
				$html .= '<b>Location Phone</b>' . $wp_location_phone . '</br>';
			}
			
			if(!empty($wp_location_email)){
				$html .= '<b>Location Email</b>' . $wp_location_email . '</br>';
			}
			
			if(!empty($wp_location_address)){
				$html .= '<b>Location Address</b>' . $wp_location_address . '</br>';
			}
			$html .= '</p>';

			
			
			if(!empty($this->wp_location_trading_hour_days)){
				$html .= '<p>';
				$html .= '<b>Location Trading Hours </b></br>';
				foreach($this->wp_location_trading_hour_days as $day_key => $day_value){
					$trading_hours = get_post_meta($post->ID, 'wp_location_trading_hours_' . $day_key , true);
					$html .= '<b>' . $day_key . '</b>' . $trading_hours . '</br>';
				}
				$html .= '</p>';
			}

			
			do_action('wp_location_meta_data_output_end',$wp_location_id);
			
			$html .= '</section>';
			$html .= $content;
			
			return $html;	
				
			
		}else{
			return $content;
		}

	}

	
	public function get_locations_output($arguments = ""){
			

		$default_args = array(
			'location_id'	=> '',
			'number_of_locations'	=> -1
		);
		
		
		if(!empty($arguments) && is_array($arguments)){
			
			foreach($arguments as $arg_key => $arg_val){
			
				if(array_key_exists($arg_key, $default_args)){
					$default_args[$arg_key] = $arg_val;
				}
			}
		}
		
		
		$html = '';

		$location_args = array(
			'post_type'		=> 'wp_locations',
			'posts_per_page'=> $default_args['number_of_locations'],
			'post_status'	=> 'publish'
		);
	
		if(!empty($default_args['location_id'])){
			$location_args['include'] = $default_args['location_id'];
		}
		
		$locations = get_posts($location_args);
		
		if($locations){
			$html .= '<article class="location_list cf">';
			
			
		
			foreach($locations as $location){
				
				
				$html .= '<section class="location">';
				
					
					
					$wp_location_id = $location->ID;
					$wp_location_title = get_the_title($wp_location_id);
					$wp_location_thumbnail = get_the_post_thumbnail($wp_location_id,'thumbnail');
					$wp_location_content = apply_filters('the_content', $location->post_content);
					if(!empty($wp_location_content)){
						$wp_location_content = strip_shortcodes(wp_trim_words($wp_location_content, 40, '...'));
					}
					$wp_location_permalink = get_permalink($wp_location_id);
					$wp_location_phone = get_post_meta($wp_location_id,'wp_location_phone',true);
					$wp_location_email = get_post_meta($wp_location_id,'wp_location_email',true);
					
					
					$html .= '<h2 class="title">';
						$html .= '<a href="' . $wp_location_permalink . '" title="view location">';
							$html .= $wp_location_title;
						$html .= '</a>';
					$html .= '</h2>';
					
				
					
					if(!empty($wp_location_thumbnail) || !empty($wp_location_content)){
								
						$html .= '<p class="image_content">';
						if(!empty($wp_location_thumbnail)){
							$html .= $wp_location_thumbnail;
						}
						if(!empty($wp_location_content)){
							$html .=  $wp_location_content;
						}
						
						$html .= '</p>';
					}
					
				
					if(!empty($wp_location_phone) || !empty($wp_location_email)){
						$html .= '<p class="phone_email">';
						if(!empty($wp_location_phone)){
							$html .= '<b>Phone: </b>' . $wp_location_phone . '</br>';
						}
						if(!empty($wp_location_email)){
							$html .= '<b>Email: </b>' . $wp_location_email;
						}
						$html .= '</p>';
					}
					
					
					$html .= '<a class="link" href="' . $wp_location_permalink . '" title="view location">View Location</a>';
				$html .= '</section>';
			}
			$html .= '</article>';
			$html .= '<div class="cf"></div>';
		}
		
		return $html;
	}
	
	
	

	public function save_location($post_id){
		
	
		if(!isset($_POST['wp_location_nonce_field'])){
			return $post_id;
		}	
	
		if(!wp_verify_nonce($_POST['wp_location_nonce_field'], 'wp_location_nonce')){
			return $post_id;
		}
	
		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
			return $post_id;
		}
	

		$wp_location_phone = isset($_POST['wp_location_phone']) ? sanitize_text_field($_POST['wp_location_phone']) : '';
		$wp_location_email = isset($_POST['wp_location_email']) ? sanitize_text_field($_POST['wp_location_email']) : '';
		$wp_location_address = isset($_POST['wp_location_address']) ? sanitize_text_field($_POST['wp_location_address']) : '';
		

		update_post_meta($post_id, 'wp_location_phone', $wp_location_phone);
		update_post_meta($post_id, 'wp_location_email', $wp_location_email);
		update_post_meta($post_id, 'wp_location_address', $wp_location_address);
		

		foreach($_POST as $key => $value){
	
			if(preg_match('/^wp_location_trading_hours_/', $key)){
				update_post_meta($post_id, $key, $value);
			}
		}
		
		
		do_action('wp_location_admin_save',$post_id);
		
	}
	

	public function enqueue_admin_scripts_and_styles(){
		wp_enqueue_style('wp_location_admin_styles', plugin_dir_url(__FILE__) . '/css/location_admin_styles.css');
	}
	
	
	public function enqueue_public_scripts_and_styles(){
		wp_enqueue_style('wp_location_public_styles', plugin_dir_url(__FILE__). '/css/location_public_styles.css');
		
	}
	
}
$wp_simple_locations = new wp_simple_location;

//include shortcodes
include(plugin_dir_path(__FILE__) . 'inc/location_shortcode.php');
//include widgets
include(plugin_dir_path(__FILE__) . 'inc/location_widget.php');



?>